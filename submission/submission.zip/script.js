/*
    Carbon Easy! (CE) web application script.
    Developed by Helen Lu.
*/

/**
 * This function is used to locate the modal element, and present it on the viewport.
 */
function register() { 
  document.getElementById("register").style.display = "block";
}